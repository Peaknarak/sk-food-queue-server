import { useState, useEffect } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { StudentDashboard } from './components/StudentDashboard';
import { VendorDashboard } from './components/VendorDashboard';

export interface User {
  id: string;
  name: string;
  type: 'student' | 'vendor';
  studentId?: string;
  vendorName?: string;
}

export interface FoodItem {
  id: string;
  name: string;
  price: number;
  image: string;
  vendorId: string;
  vendorName: string;
  available: boolean;
}

export interface CartItem extends FoodItem {
  quantity: number;
}

export interface Order {
  id: string;
  studentId: string;
  studentName: string;
  items: CartItem[];
  totalAmount: number;
  status: 'waiting' | 'confirmed' | 'rejected';
  queueNumber?: number;
  vendorId: string;
  vendorName: string;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  message: string;
  timestamp: Date;
  orderId?: string;
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute to check booking window
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const isBookingTimeActive = () => {
    const now = currentTime;
    const hour = now.getHours();
    return hour >= 8 && hour < 10; // 8:00 AM - 10:00 AM
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  if (!currentUser) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {currentUser.type === 'student' ? (
        <StudentDashboard 
          user={currentUser} 
          onLogout={handleLogout}
          isBookingActive={isBookingTimeActive()}
          currentTime={currentTime}
        />
      ) : (
        <VendorDashboard 
          user={currentUser} 
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}

export default App;