import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User } from '../App';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [studentId, setStudentId] = useState('');
  const [vendorCode, setVendorCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleStudentLogin = async () => {
    if (!studentId) return;
    
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      const user: User = {
        id: studentId,
        name: `Student ${studentId}`,
        type: 'student',
        studentId: studentId
      };
      onLogin(user);
      setLoading(false);
    }, 1000);
  };

  const handleVendorLogin = async () => {
    if (!vendorCode) return;
    
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      const vendorNames = {
        'V001': 'Thai Kitchen',
        'V002': 'Western Grill',
        'V003': 'Noodle Station',
        'V004': 'Fresh Salads'
      };
      
      const user: User = {
        id: vendorCode,
        name: vendorNames[vendorCode as keyof typeof vendorNames] || 'Unknown Vendor',
        type: 'vendor',
        vendorName: vendorNames[vendorCode as keyof typeof vendorNames] || 'Unknown Vendor'
      };
      onLogin(user);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Suankularb Wittayalai</CardTitle>
          <CardDescription>School Canteen Booking System</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="student" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="student">Student</TabsTrigger>
              <TabsTrigger value="vendor">Vendor</TabsTrigger>
            </TabsList>
            
            <TabsContent value="student" className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="studentId" className="text-sm">Student ID</label>
                <Input
                  id="studentId"
                  type="text"
                  placeholder="Enter your student ID"
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleStudentLogin} 
                className="w-full"
                disabled={loading || !studentId}
              >
                {loading ? 'Logging in...' : 'Login as Student'}
              </Button>
              <p className="text-xs text-muted-foreground">
                Demo IDs: 12345, 67890, 11111
              </p>
            </TabsContent>
            
            <TabsContent value="vendor" className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="vendorCode" className="text-sm">Vendor Code</label>
                <Input
                  id="vendorCode"
                  type="text"
                  placeholder="Enter your vendor code"
                  value={vendorCode}
                  onChange={(e) => setVendorCode(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleVendorLogin} 
                className="w-full"
                disabled={loading || !vendorCode}
              >
                {loading ? 'Logging in...' : 'Login as Vendor'}
              </Button>
              <p className="text-xs text-muted-foreground">
                Demo codes: V001, V002, V003, V004
              </p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
