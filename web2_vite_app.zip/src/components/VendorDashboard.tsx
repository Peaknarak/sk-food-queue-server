import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, Order } from '../App';
import { VendorOrders } from './VendorOrders';
import { ChatSystem } from './ChatSystem';
import { ClipboardList, MessageCircle, LogOut, Store } from 'lucide-react';

interface VendorDashboardProps {
  user: User;
  onLogout: () => void;
}

export function VendorDashboard({ user, onLogout }: VendorDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState({
    pending: 0,
    confirmed: 0,
    rejected: 0,
    totalRevenue: 0
  });

  // Mock orders for this vendor
  useEffect(() => {
    const mockOrders: Order[] = [
      {
        id: '1',
        studentId: '12345',
        studentName: 'Student 12345',
        items: [
          { id: '1', name: 'Pad Thai', price: 45, image: '', vendorId: user.id, vendorName: user.name, available: true, quantity: 1 },
          { id: '2', name: 'Thai Tea', price: 25, image: '', vendorId: user.id, vendorName: user.name, available: true, quantity: 1 }
        ],
        totalAmount: 70,
        status: 'waiting',
        vendorId: user.id,
        vendorName: user.name,
        createdAt: new Date(Date.now() - 1800000)
      },
      {
        id: '2',
        studentId: '67890',
        studentName: 'Student 67890',
        items: [
          { id: '3', name: 'Green Curry', price: 55, image: '', vendorId: user.id, vendorName: user.name, available: true, quantity: 2 }
        ],
        totalAmount: 110,
        status: 'confirmed',
        queueNumber: 12,
        vendorId: user.id,
        vendorName: user.name,
        createdAt: new Date(Date.now() - 3600000)
      },
      {
        id: '3',
        studentId: '11111',
        studentName: 'Student 11111',
        items: [
          { id: '4', name: 'Mango Sticky Rice', price: 40, image: '', vendorId: user.id, vendorName: user.name, available: true, quantity: 1 }
        ],
        totalAmount: 40,
        status: 'waiting',
        vendorId: user.id,
        vendorName: user.name,
        createdAt: new Date(Date.now() - 900000)
      }
    ];
    setOrders(mockOrders);
  }, [user]);

  // Calculate stats
  useEffect(() => {
    const pending = orders.filter(order => order.status === 'waiting').length;
    const confirmed = orders.filter(order => order.status === 'confirmed').length;
    const rejected = orders.filter(order => order.status === 'rejected').length;
    const totalRevenue = orders
      .filter(order => order.status === 'confirmed')
      .reduce((sum, order) => sum + order.totalAmount, 0);

    setStats({ pending, confirmed, rejected, totalRevenue });
  }, [orders]);

  const updateOrderStatus = (orderId: string, status: 'confirmed' | 'rejected', queueNumber?: number) => {
    setOrders(prev =>
      prev.map(order =>
        order.id === orderId
          ? { ...order, status, queueNumber }
          : order
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Store className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl text-gray-900">Vendor Portal</h1>
                <p className="text-sm text-gray-600">{user.name}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={onLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Orders</p>
                  <p className="text-2xl">{stats.pending}</p>
                </div>
                <Badge variant="secondary">{stats.pending}</Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Confirmed</p>
                  <p className="text-2xl">{stats.confirmed}</p>
                </div>
                <Badge variant="default">{stats.confirmed}</Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Rejected</p>
                  <p className="text-2xl">{stats.rejected}</p>
                </div>
                <Badge variant="destructive">{stats.rejected}</Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Revenue Today</p>
                  <p className="text-2xl">₿{stats.totalRevenue}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="orders">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              Manage Orders
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              Customer Chat
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <VendorOrders 
              orders={orders}
              onUpdateOrderStatus={updateOrderStatus}
            />
          </TabsContent>

          <TabsContent value="chat">
            <ChatSystem 
              currentUser={user}
              orders={orders}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}