import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, FoodItem, CartItem, Order } from '../App';
import { FoodBrowser } from './FoodBrowser';
import { Cart } from './Cart';
import { OrderHistory } from './OrderHistory';
import { ChatSystem } from './ChatSystem';
import { Clock, ShoppingCart, History, MessageCircle, LogOut } from 'lucide-react';

interface StudentDashboardProps {
  user: User;
  onLogout: () => void;
  isBookingActive: boolean;
  currentTime: Date;
}

export function StudentDashboard({ user, onLogout, isBookingActive, currentTime }: StudentDashboardProps) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState('browse');

  // Mock orders data
  useEffect(() => {
    const mockOrders: Order[] = [
      {
        id: '1',
        studentId: user.id,
        studentName: user.name,
        items: [
          { id: '1', name: 'Pad Thai', price: 45, image: '', vendorId: 'V001', vendorName: 'Thai Kitchen', available: true, quantity: 1 },
          { id: '2', name: 'Thai Tea', price: 25, image: '', vendorId: 'V001', vendorName: 'Thai Kitchen', available: true, quantity: 1 }
        ],
        totalAmount: 70,
        status: 'confirmed',
        queueNumber: 15,
        vendorId: 'V001',
        vendorName: 'Thai Kitchen',
        createdAt: new Date(Date.now() - 3600000) // 1 hour ago
      },
      {
        id: '2',
        studentId: user.id,
        studentName: user.name,
        items: [
          { id: '5', name: 'Burger Combo', price: 120, image: '', vendorId: 'V002', vendorName: 'Western Grill', available: true, quantity: 1 }
        ],
        totalAmount: 120,
        status: 'waiting',
        vendorId: 'V002',
        vendorName: 'Western Grill',
        createdAt: new Date(Date.now() - 1800000) // 30 minutes ago
      }
    ];
    setOrders(mockOrders);
  }, [user]);

  const addToCart = (foodItem: FoodItem) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === foodItem.id);
      if (existing) {
        return prev.map(item =>
          item.id === foodItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...foodItem, quantity: 1 }];
    });
  };

  const updateCartQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCartItems(prev => prev.filter(item => item.id !== id));
    } else {
      setCartItems(prev =>
        prev.map(item =>
          item.id === id ? { ...item, quantity } : item
        )
      );
    }
  };

  const placeOrder = (items: CartItem[], totalAmount: number) => {
    const vendorId = items[0]?.vendorId || '';
    const vendorName = items[0]?.vendorName || '';
    
    const newOrder: Order = {
      id: Date.now().toString(),
      studentId: user.id,
      studentName: user.name,
      items: [...items],
      totalAmount,
      status: 'waiting',
      vendorId,
      vendorName,
      createdAt: new Date()
    };
    
    setOrders(prev => [newOrder, ...prev]);
    setCartItems([]);
    setActiveTab('orders');
  };

  const formatTime = (time: Date) => {
    return time.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl text-gray-900">Canteen Booking</h1>
              <p className="text-sm text-gray-600">Welcome, {user.name}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <span className="text-sm">{formatTime(currentTime)}</span>
                <Badge variant={isBookingActive ? "default" : "secondary"}>
                  {isBookingActive ? 'Booking Open' : 'Booking Closed'}
                </Badge>
              </div>
              {cartItems.length > 0 && (
                <div className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
                    {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </Badge>
                </div>
              )}
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!isBookingActive && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="pt-6">
              <p className="text-amber-800">
                <Clock className="inline h-4 w-4 mr-2" />
                Booking is only available between 8:00 AM - 10:00 AM
              </p>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse" className="flex items-center gap-2">
              <ShoppingCart className="h-4 w-4" />
              Browse Food
            </TabsTrigger>
            <TabsTrigger value="cart" className="flex items-center gap-2">
              <ShoppingCart className="h-4 w-4" />
              Cart ({cartItems.length})
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              My Orders
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              Chat
            </TabsTrigger>
          </TabsList>

          <TabsContent value="browse">
            <FoodBrowser 
              onAddToCart={addToCart}
              isBookingActive={isBookingActive}
            />
          </TabsContent>

          <TabsContent value="cart">
            <Cart 
              items={cartItems}
              onUpdateQuantity={updateCartQuantity}
              onPlaceOrder={placeOrder}
              isBookingActive={isBookingActive}
            />
          </TabsContent>

          <TabsContent value="orders">
            <OrderHistory orders={orders} />
          </TabsContent>

          <TabsContent value="chat">
            <ChatSystem 
              currentUser={user}
              orders={orders}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}